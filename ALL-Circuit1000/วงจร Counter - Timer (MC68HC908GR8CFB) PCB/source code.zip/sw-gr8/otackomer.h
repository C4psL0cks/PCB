#include<iogr8.h>

typedef unsigned long int uli;
typedef unsigned char uchar;

extern unsigned char count3b;
extern unsigned char disp[];
extern const char seg[];

extern unsigned int rpm;
extern unsigned int dispupd;
extern unsigned char notmeas;
extern uli delay;
extern uli lastpulse;

extern unsigned char keypress;		  /* keypess map */
extern unsigned char keys; 			  /* keys map */
extern unsigned char keypresslng;	  /* long keypess map */
extern unsigned char keyslng; 		  /* long keys map */

void disp_rfsh(void);
void display_init(void);

void count_xtd(void);
//void count_ctrl(void);
void signal_in(void);
void counter_init(void);
extern unsigned char overctrl;

extern uchar progspace[];
struct nv { unsigned int seq;
	   	  	unsigned int presetrpm;
            uchar checksum; };
extern struct nv ee;
void setup_vars(void);
void save_ee(void);
extern void flash_program(void* dest, void* src,unsigned char lng);
extern void flash_erase(void* dest);
