#include"otackomer.h"

struct nv ee;


void cgm_setup(void) // 32.768kHz -> 4.9152MHz
{
   PCTL=0x00;
   PCTL=0x02;
   PBWC=0xD0;
   PMSH=0x02;
   PMSL=0x58;
   PMRS=0x80;
   PMDS=0x01;
   PCTL|=0x20;
   while(!(PBWC&0x40));
   PCTL|=0x10;
}

void dispput(unsigned int val)
{
   unsigned char i;
   
   if(val>9999)
   { disp[0]=disp[1]=disp[2]=disp[3]=0x40; }
   else
   {
   	  for(i=0;i<4;i++)
	  {
	     disp[i]=seg[val%10];
		 val/=10;
      }   
   }
}

const unsigned int digvals[]={1,10,100,1000};

void main(void)
{
   unsigned int i,j,digit,digval;
   unsigned int rpm,rpm2,lrpm2;
   
   cgm_setup();
   counter_init();
   display_init();

   SCC1=0;
   
   DDRE=1; // PTE0 - warning light output
   
   ee.presetrpm=2500;
   ee.seq=1;
   
   setup_vars();
   
   asm("cli");
   
   for(i=0;i<4;i++)
   {
	  disp[i+4]=0;
   }

   while(1)
   {
      i=0;
	  if(keypresslng&0x08)	 // SET
	  {   
	  	 for(digit=3;digit<5;digit--)
		 {
		  	digval=digvals[digit];
		    for(j=0;j<4;j++) // Dimm display
	           disp[j+4]=0x77;
    	 	dispput(ee.presetrpm);
			i=(ee.presetrpm/digval)%10; //Destilate current digit
			ee.presetrpm-=digval*i;
			disp[digit+4]=0x07;
	     	while(keys&0x0C);   // Wait for release of ALL keys
	     	keypress&=~0x0C;	 // Clear late keypresses
	     	keypresslng&=~0x0C;
         	while(!(keypress&0x08))
   	     	{
	           if(keypress&0x04)
		       {
		          keypress&=~0x04;
		       	  i++;
				  if(i>9) i=0;
			   	  dispput(ee.presetrpm+digval*i);
		       }
            }
			ee.presetrpm+=digval*i;
		 }
	     keypresslng&=~0x0C;
	     keypress&=~0x0C;
         for(i=0;i<4;i++)  // Light up all digits
         {
	        disp[i+4]=0;
         }
		 save_ee();
	  }
	  rpm2=(delay>4096)?294912000/delay:65000;
	  if(notmeas>180) { rpm2=0; rpm=0; }
	  
	  if(rpm2<(ee.presetrpm<<1))
	     PTE|=1;
	  else
	     PTE&=~1;

      if((rpm2>lrpm2+1)||(rpm2<lrpm2-1))
	  {
	     rpm=rpm2>>1;
		 lrpm2=rpm2;
	  }	  	  

      if(!dispupd)
	  {
	     dispput(rpm);
		 dispupd=30;
	  }
   }
}