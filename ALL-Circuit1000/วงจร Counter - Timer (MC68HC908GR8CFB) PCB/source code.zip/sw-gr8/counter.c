#include"otackomer.h"

unsigned int countxtd,dispupd; // 3rd and 4th byte of timecounter */
unsigned char overctrl,invmeas,badmeas,notmeas;
unsigned long int lastpulse,delay; // Timestamp of last pulse

/* Counter overflow - rotations under resolution */
//#pragma interrupt_handler count_ctrl
//void count_ctrl(void)
//{
//   T2SC1&=~0x80;
//   overctrl=1;
//}

#pragma interrupt_handler count_xtd
void count_xtd(void)
{
   T2SC&=~0x80;
   asm("cli");
   countxtd++;
   overctrl=0;
   if(notmeas<255) notmeas++;
   if((notmeas>140)&&(!invmeas)) invmeas=1;
   if(dispupd) dispupd--;
}

#pragma interrupt_handler signal_in
void signal_in(void)
{
   uli currpulse;
   uchar tmpvar;
   T2SC0&=~0x80;
   tmpvar=T2CH0H;
   currpulse=((uli)countxtd<<16)|((uli)tmpvar<<8)|(uli)T2CH0L;
   if(overctrl&&(~tmpvar&0x80)) currpulse+=65536;
   delay=currpulse-lastpulse;
   if(delay>4096) lastpulse=currpulse;
//   lastpulse=currpulse;

   if(!invmeas)
   {
      if((delay<9830400)&&(delay>4096))
      {
		 notmeas=0;
      }
   } else { invmeas--; notmeas=0;}
}

void counter_init(void)
{
   T2SC=0x70;  // Reset, hold, BUSCLK/1
   T2MODH=0xFF;   // Round trip = 64k
   T2MODL=0xFF;
   T2SC0=0x48;  //Ch0 - i.c. on falling edge, interrupts
   invmeas=5;	//next 5 measurements will be invalided
   countxtd=0;
   overctrl=0;
   lastpulse=0;
   badmeas=1;
   notmeas=150;
   delay=0;
   dispupd=0;
   T2SC&=~0x20; //Start counter
}