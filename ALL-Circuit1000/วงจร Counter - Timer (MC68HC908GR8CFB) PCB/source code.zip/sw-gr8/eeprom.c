#include"otackomer.h"

const struct nv* eepage1=(const struct nv*)0xE000; 
const struct nv* eepage2=(const struct nv*)0xE080;

unsigned char progspace[128];

unsigned char make_checksum(struct nv* data)
{
 	int i;
	unsigned char* dta=(unsigned char*)data;
	unsigned char chksum=0;
	for(i=0;i<sizeof(struct nv)-1;chksum+=dta[i++]);
	return(~chksum);
} 	

void memcpy(void* dst, void* src, int lng)
{
    int i;
	char*dest=(char*)dst;
	char*sorc=(char*)src;
	for(i=0;i<lng;i++) dest[i]=sorc[i];
}

void setup_vars(void)
{
// 	unsigned long int rtc1=0,rtc2=0;
	unsigned char* dta;
	int	i;
	
/* Default setup (initial, or w/ invalid eeprom) */	
	dta=(char*)&ee;
    for(i=0;i<sizeof(struct nv);dta[i++]=0);

/* Clearing invalid EEPROM data */

    if(eepage1->seq!=(unsigned int)-1)
		if(eepage1->checksum!=make_checksum((struct nv*)eepage1))
		    flash_erase((void*)eepage1);
    if(eepage2->seq!=(unsigned int)-1)
		if(eepage2->checksum!=make_checksum((struct nv*)eepage2))
		    flash_erase((void*)eepage2);
		
/* Clearing old EEPROM data */	
			
    if((eepage1->seq!=(unsigned int)-1)&&(eepage2->seq!=(unsigned int)-1)) 
		if(eepage1->seq<eepage2->seq) flash_erase((void*)eepage1);
		   else flash_erase((void*)eepage2);
	
/* EEPROM data pumping out*/

	if(eepage1->seq!=(unsigned int)-1)
	    memcpy(&ee,(void*)eepage1,sizeof(struct nv));
	if(eepage2->seq!=(unsigned int)-1)
	    memcpy(&ee,(void*)eepage2,sizeof(struct nv));
}

void save_ee(void)
{
    if((eepage1->seq!=(unsigned int)-1)&&(eepage2->seq!=(unsigned int)-1)) 
		if(eepage1->seq<eepage2->seq) flash_erase((void*)eepage1);
		   else flash_erase((void*)eepage2);
    asm("sei");
	ee.seq++;
    ee.checksum=make_checksum(&ee);
    if(eepage1->seq!=(unsigned int)-1)
	   flash_program((void*)eepage2,&ee,sizeof(ee));
	else 
	   flash_program((void*)eepage1,&ee,sizeof(ee));
	ee.seq++;
	asm("cli");
}


