#include"otackomer.h"

#pragma interrupt_handler isrDummy
void isrDummy(void) 
	{
	}


	
#pragma abs_address:0xffdc

void (* const _vectab[])(void) = {
	isrDummy,				/*16 Timebase        	*/
	isrDummy,				/*15 ADC             	*/
	isrDummy, 				/*14 KBI             	*/
	isrDummy,				/*13 SCI TC/TE       	*/
	isrDummy,				/*12 SCI RF/IDLE     	*/
	isrDummy,				/*11 SCI PE/FE/NF/OR 	*/
	isrDummy,				/*10 SPI Tx        	*/
	isrDummy,				/*9 SPI Rx        	*/
	count_xtd,				/*8 TIM2 OVR			*/
	isrDummy,				/*7             	*/
	signal_in,				/*6 TIM2 channel 0	*/
	disp_rfsh,				/*5 TIM1 OVR      	*/
	isrDummy,				/*4 TIM1 channel 1	*/
	isrDummy,				/*3 TIM1 channel 0	*/
	isrDummy,				/*2 PLL          	*/
	isrDummy,				/*1 IRQ          	*/
	isrDummy				/*0 SWI             	*/
/*	RESET defined in crt08.o */
	};
